# App Engine Standard Environment & Endpoints Frameworks skeleton

<a href="https://console.cloud.google.com/cloudshell/open?git_repo=https://github.com/GoogleCloudPlatform/java-docs-samples&page=editor&open_in_editor=appengine-java8/endpoints-v2-skeleton/README.md">
<img alt="Open in Cloud Shell" src ="http://gstatic.com/cloudssh/images/open-btn.png"></a>

This is a skeleton example for getting setup with Endpoints Framework v2 for
Java.

For a more complete example of using Endpoints Framework v2 for Java review
the [backend example](/appengine-java8/endpoints-v2-backend).
